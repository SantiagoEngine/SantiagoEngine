function onCreate()
	for i = 0, getProperty('unspawnNotes.length')-1 do
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Yourcustomnotename' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'Yournote_assets'); 
				setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', true);
		end
	end
	--debugPrint('Script started!')
	function noteMiss(id, i, noteType, isSustainNote)
		if noteType == 'Yourcustomnotename' then
            -- Function
	end
end
end

function goodNoteHit(id, noteData, noteType, isSustainNote)
	if noteType == 'Yourcustomnotename' then
		-- Function
	end
end