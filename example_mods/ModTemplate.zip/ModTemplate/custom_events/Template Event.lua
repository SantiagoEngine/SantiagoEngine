-- strumTime is optional

function onEvent(Name, value1, value2, strumTime)
    if name == 'Nameofyourevent' then
        if value1 == 'value' then
            --Code if value one is defined value.
        
        if value2 == 'value' then
            --Code if value two is defined value
        end
    end
end