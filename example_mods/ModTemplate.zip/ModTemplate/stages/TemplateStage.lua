function onCreate()
	makeLuaSprite('TAGNAME', 'IMGNAME', -650, -460); -- X and Y axis.
	setScrollFactor('TAGNAME', 0.9, 0.9); -- Scroll Factor.
	scaleObject('TAGNAME', 1.1, 1.1); -- Scale.
	addLuaSprite('TAGNAME', false); -- False makes it behind the characters, true makes it in front.
	
	close(true); -- Close this script, performace reasons.
end