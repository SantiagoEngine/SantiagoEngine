Put your custom charts here.

The credits.txt should be formatted like this:

YourMod
YourName::YourIcon::YourDescription::https://your.link/::yourhexadecimalcolor